<?php

namespace Eldermann1337\AboutYourServer;

use pocketmine\plugin\PluginBase;
use pocketmine\Server;

class Main extends PluginBase {

}
